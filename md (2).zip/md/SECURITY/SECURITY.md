# Security

Related: [Secrets](SECRETS.md), [Tenant isolation](TENANT_ISOLATION.md), [Authentication](../API/AUTHENTICATION.md), [MCP architecture](../MCP/MCP_ARCHITECTURE.md).

## Authentication

JWT HS256 (`auth/tokens.py`), cookie `access_token` or Bearer, server-side `sessions` row. Passwords are bcrypt. Details: [Authentication](../API/AUTHENTICATION.md).

## Encryption

`db/crypto.py` `TokenEncryptor` uses Fernet and `TOKEN_ENCRYPTION_KEY`. It wraps Instagram access tokens, Canva access and refresh tokens, and Canva PKCE verifiers. Without the key, connect routes cannot store a token.

## Logging

`services/logging.py` replaces secret-like substrings with `[REDACTED]` via `redact_text`. `AppError` messages pass through that redaction in the HTTP handler. Optional integration failures in `scheduler/integrations.py` log the module name and not the exception text, so a provider key in an error string is less likely to be written.

## Publishing boundary

MCP, DeepSeek, OpenAI, Canva, the trend stack, the agent runtime, and the React builder cannot call `media_publish`. The allowlist check runs before any handler. The Instagram Agent is the only registered publisher. The scheduler campaign path calls `PublicationService`, which runs that agent. See [Architecture](../ARCHITECTURE.md) and [the platform audit](../AGENT_PLATFORM_FINAL_AUDIT.md).

Canva access and refresh tokens stay in the encrypted `canva_connections` row and in the adapter's MCP session. They are not sent to DeepSeek, OpenAI, the React app, MCP tool results, or log lines. A Canva export download does not attach the access token. Canva tool names that contain `publish` or `instagram` are refused before the remote call.

## HTTP

CORS origins come from `CORS_ORIGINS` and allow credentials. Graph hosts are allowlisted. `allow_insecure_graph_http` defaults to false.

Public media URLs are unauthenticated by design. They are not a directory listing. Generated and brand bytes require a session.

## Gaps

| Item | Status |
| --- | --- |
| Global `META_ACCESS_TOKEN` fallback | Closed for production, staging, and the default (`APP_ENV` unset is `production`). Publishing uses the user's encrypted token. The process token is used only when `APP_ENV` is `development`, `dev`, or `local`, `INSTAGRAM_LEGACY_ENV_FALLBACK=true`, and the caller opts in. The scheduler does not opt in |
| `JWT_SECRET` default `dev-change-me` when unset | PARTIAL. Replace before any shared deployment |
| Cookie `Secure` default false | Expected for local HTTP. Set `JWT_COOKIE_SECURE=true` behind HTTPS |
| Instagram OAuth | NOT IMPLEMENTED. The user pastes a token |
| CSRF token | NOT IMPLEMENTED. Cookie is `HttpOnly` and `SameSite=Lax`. Mutations have no separate CSRF check |
| Agent configuration durability | NOT IMPLEMENTED. `/api/v1/agents` and `/api/v1/platform/agents` keep records in process memory |
| Agent routes | IMPLEMENTED and session-scoped. They reject publishing tool names. Execute is a test and does not call Meta |
