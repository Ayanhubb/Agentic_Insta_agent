# Final implementation report

Verified against the working tree on 2026-09-24. This replaces the 21 September snapshot that predated MCP, DeepSeek planning, Canva, brand assets, and trend storage. Agent platform packages added after this report are not in the tables below. Their status is [the final audit](../AGENT_PLATFORM_FINAL_AUDIT.md).

Related: [Integration audit](FINAL_INTEGRATION_AUDIT.md), [Architecture](../ARCHITECTURE.md).

## Stack

| Layer | Implementation |
| --- | --- |
| UI | React 19, Vite 7, routes in `frontend/src/App.tsx` |
| API | FastAPI `2.0.0`, prefix `/api/v1` |
| Auth | JWT HS256, cookie `access_token`, bcrypt, `sessions` table |
| Data | SQLAlchemy models in `db/models.py`, Alembic `001`–`006`, SQLite by default |
| MCP | In-process allowlist of 22 read tools in `backend/mcp/` |
| Studio planner | DeepSeek when `DEEPSEEK_API_KEY` is set, else `GroundedCreativeModel`. **IMPLEMENTED — NOT CONFIGURED** |
| Scheduler planner | `ContentAgent` plus `LLM_PROVIDER` (default `deepseek`). Missing key uses `MockLLMProvider`, not OpenAI. **IMPLEMENTED — NOT CONFIGURED** |
| Trend analysis | MCP evidence, including Instagram `trend_context`, then `DeepSeekTrendAnalyst`. **IMPLEMENTED — NOT CONFIGURED** |
| Images | OpenAI generation, and OpenAI edit when MCP has a logo or product file. **IMPLEMENTED — NOT CONFIGURED**. Production logos and product images are not uploaded yet |
| Vision | DeepSeek when the vision factory loads, else structural QA. **IMPLEMENTED — NOT CONFIGURED** |
| Publisher | `InstagramAgent` only. `META_ACCESS_TOKEN` is not a production fallback |
| Canva | Creative MCP only. Never publishes. **IMPLEMENTED — NOT CONFIGURED** (`CANVA_ENABLED` defaults to false) |
| Scheduler | In-process loop, off unless `SCHEDULER_ENABLED` |

## Publishing

`POST /api/v1/instagram/publish` and `POST /api/v1/generation/{id}/approve` and the scheduler pipeline all reach Meta through the Instagram Agent tools in `tools/instagram_media.py`. MCP rejects publish tool names. Content orchestration returns `published: false`.

Only `PUBLISHED` with `instagram_media_id` counts. Unknown publish certainty is not retried.

## Trends

`TrendResearcher` fetches explicit URLs on an allowlist of Indian news and government hosts. `DeepSeekTrendAnalyst` writes a brief from stored evidence and is not a browser. Opportunities are recommendations. The trend tick does not publish by itself.

## Festivals

47 named entries in `festivals/india_festivals.py`, with year-keyed civil dates and `lunar_dates.json` overrides. Default campaign size is 2 posts. Timezone `Asia/Kolkata`.

## Not in this build

- DeepSeek image generation
- Reels, stories, carousels
- Instagram OAuth code flow
- A live `real_deepseek` test in the default suite (the provider is implemented; the key is not configured, and live tests stay optional)
- Semantic similarity beyond token overlap
- `LLMPlanner` as a production planner
